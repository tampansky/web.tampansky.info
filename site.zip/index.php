<?php
include("../site/app/header.php");
include("../site/app/style.php");
?>
<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="?"><img src="https://i.ibb.co/ftfQ5M8/20200210-175051.png" width="198" height="48" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav wh ml-auto">
                    <a class="nav-item nav-link active link" href="#" data-scroll-nav="0">Home <span class="sr-only">(current)</span></a>
                    <a class="nav-item nav-link link" href="#" data-scroll-nav="1">Team</a>
                    <a class="nav-item nav-link link" href="#" data-scroll-nav="2">skill</a>
                    <a class="nav-item nav-link link" href="#" data-scroll-nav="3">About</a>
                </div>
            </div>
        </div>
    </nav>
</div>
<!--start home area-->
<section id="home-area" class="qmak" data-scroll-index="0">
    <div class="container">
        <div class="row">
            <!--start caption-->
            <div class="col-lg-7 col-md-8">
                <div class="caption two d-table">
                    <div class="d-table-cell align-middle">
                        <h1 class="mb-3">Welcome to my website</span>
                        </h1>
                        <h4 class="text-dark font-open-sans">Hadi prasetia adalah seorang pelajar yang sangat menyukai Seputar Dunia Internet.</h4>
                        <div class="caption-btns v2">
                            <a class="btn btn-secondary bg-success" href="#" data-scroll-nav="4">Show More.</a>
                        </div>
                    </div>
                </div>
            </div>
            <!--end caption-->
        </div>
    </div>
</section>
<!--start home area-->
<br>
<br>
<br>
<br>
<!-- Start Team Area -->
<section id="team-area" data-scroll-index="1">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2">
                <div class="section-heading text-center">
                    <h5>Our Team</h5>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <!--start team single-->
            <div class="col-lg-3 col-md-6">
                <div class="team-single text-center">
                    <div class="team-img">
                        <img src="https://i.ibb.co/sFgdkQK/20191206-190553.png" class="img-fluid" alt="">
                        <div class="team-social two">
                            <ul>
                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                <li><a href=""><i class="icofont-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team-info">
                        <h3>Black Coders Anonymous</h3>
                        <p>Hacker | Coder | Defacer</p>
                    </div>
                </div>
            </div>
            <!-- Black Coder Anon -->
            <!--start team single-->
            <div class="col-lg-3 col-md-6">
                <div class="team-single text-center">
                    <div class="team-img">
                        <img src="https://raw.githubusercontent.com/BCA-X666X-TEAM/bca-x666x-team.github.io/master/7gt-hp2.png" class="img-fluid" alt="">
                        <div class="team-social two">
                            <ul>
                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                <li><a href=""><i class="icofont-linkedin"></i></a></li>
                                </li>
                                <!-- <li><a href=""><i class="icofont-linkedin"></i></a></li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="team-info">
                        <h3>Seven Ghost Team</h3>
                        <p>Coder | Hacker | Defacer</p>
                    </div>
                </div>
            </div>
            <!--end team single-->
            <!--start team single-->
            <div class="col-lg-3 col-md-6">
                <div class="team-single text-center">
                    <div class="team-img">
                        <img src="https://scontent.fcgk18-2.fna.fbcdn.net/v/t1.0-9/52851295_2102635759789646_5819622244460003328_n.jpg?_nc_cat=107&_nc_ohc=MN9p_pOrsdcAX9jn5GZ&_nc_ht=scontent.fcgk18-2.fna&oh=d6c68b9200f04841674ee3d7dd2785b3&oe=5ECFBF8B" class="img-fluid" alt="">
                        <div class="team-social two">
                            <ul>
                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                <li><a href=""><i class="icofont-linkedin"></i></a></li>
                                </li>
                                <!-- <li><a href=""><i class="icofont-linkedin"></i></a></li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="team-info">
                        <h3>Black Coder Crush</h3>
                        <p>Coder | Developer</p>
                    </div>
                </div>
            </div>
            <!--end team single-->
        </div>
    </div>
</section>
<!-- End Team Area -->

<section id="how-work-area" class="bg-3" data-scroll-index="2">
    <div class="container">
        <div class="row">
            <!--start section heading-->
            <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2">
                <div class="section-heading text-center">
                    <h2>Skill Yang dimiliki oleh admin</h2>
                    <p>
                    </p>
                </div>
            </div>
            <!--end section heading-->
        </div>
        <div class="row how-work-wrap">
            <div class="how-work-bg"></div>
            <!--start how work single-->
            <div class="col-lg-offset-1 col-lg-3 col-md-4">
                <div class="how-work-single">
                    <div class="icon">
                        <i class="icofont-flask"></i>
                        <div class="number">01</div>
                    </div>
                    <h3>Internet</h3>
                    <p>Internet (portmanteau dari interconnected network) adalah sistem jaringan komputer yang saling terhubung secara global dengan menggunakan paket protokol internet (TCP/IP) untuk menghubungkan perangkat di seluruh dunia.</p>
                </div>
            </div>
            <!--end how work single-->
            <!--start how work single-->
            <div class="col-lg-3 col-md-4">
                <div class="how-work-single two">
                    <div class="icon">
                        <i class="icofont-layout"></i>
                        <div class="number">02</div>
                    </div>
                    <h3>Deface</h3>
                    <p>Website defacement is an attack on a website that changes the visual appearance of a website or a web page. ... Defacement is generally meant as a kind of electronic graffiti and, as other forms of vandalism, is also used to spread messages by politically motivated "cyber protesters" or hacktivists.</p>
                </div>
            </div>
            <!--end how work single-->
            <!--start how work single-->
            <div class="col-lg-3 col-md-4">
                <div class="how-work-single three">
                    <div class="icon">
                        <i class="icofont-code"></i>
                        <div class="number">03</div>
                    </div>
                    <h3>Coding</h3>
                    <p>Coding is the process of using a programming language to get a computer to behave how you want it to. Every line of code tells the computer to do something, and a document full of lines of code is called a script. Each script is designed to carry out a job</p>
                </div>
            </div>
            <!--end how work single-->
        </div>
    </div>
</section>
<!--end how work area-->
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<!--start custom plan area-->
<section id="custom-plan-area" data-scroll-index="3">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="custom-plan-wrap bg-2 row">
                    <div class="col-md-8 offset-md-2">
                        <div class="section-heading text-center">
                            <h5 class="text-light">About Website</h5>
                            <h2 class="text-white">Siapa Yang Buat Website Ini ?</h2>
                            <p class="text-white">Yang buat website ini adalah tampansky. Pasti Tau Lah Siapa Dia :V , Diatas Ada Tuh Namanya awkoakwo :V</p>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="plan-btn two text-center btn-lg">
                            <a href="https://wa.me/6285779000116" target="_blank">Lets Chat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--end custom plan area-->

<br>
<br>
<br>
<br>
<!--start footer-->
<footer id="footer" class="bg-2">
    <div class="container">
        <div class="footer-copyright">
            <div class="col-lg-6 col-md-7">
                <p>&copy; 2020 Tampansky ID | All right reserved.</p>
            </div>
        </div>
    </div>
    </div>
</footer>


<?php
include("../site/app/footer.php");
?>