<style>
    @import url('https://fonts.googleapis.com/css?family=Bitter|Chela+One|Lacquer|Russo+One&display=swap');

    body {
        background: white;
    }

    asw {
        color: ;
    }

    .sl {
        font-family: "Bitter";
        color: gray;
    }

    .ph {
        font-family: "Chela One";
        color: gray;
        text-shadow: 0px 0px 5px black;
    }

    .wh {
        font-family: "Russo One";
        color: white;
        padding: 10px;
    }

    .qmak {
        background: url(https://i.ytimg.com/vi/5-LyRjHlRgQ/maxresdefault.jpg);
        background-size: 100% 100%;
        background-attachment: fixed;
        margin-bottom: 10px;
    }

    .link:hover {
        color: white;
        transition: all 0.5s ease;
    }

    @media (min-width: 1200px) {}
</style>